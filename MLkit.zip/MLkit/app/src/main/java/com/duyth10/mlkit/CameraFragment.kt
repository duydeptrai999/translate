package com.duyth10.mlkit

import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.media.Image
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.isInvisible
import androidx.fragment.app.Fragment
import com.duyth10.mlkit.databinding.FragmentCameraBinding
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.nio.ByteBuffer
import java.util.concurrent.ExecutionException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.atan2
import kotlin.math.pow


class CameraFragment : Fragment() {

    private var _binding: FragmentCameraBinding? = null
    private val binding get() = _binding!!
    private lateinit var imageCapture: ImageCapture
    private var capturedBitmap: Bitmap? = null
    private var currentTranslator: Translator? = null

    private var recognizedTextBlocks = mutableListOf<Quad>() // Các vị trí văn bản đã nhận dạng
    private var originalTextBlocks = mutableListOf<String>() // Văn bản gốc đã nhận dạng


    private val REQUIRED_PERMISSIONS = arrayOf(
        android.Manifest.permission.CAMERA
    )

    private val requestMultiplePermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.all { it.value }) {
            startCamera()
        } else {
            Log.d("permissions", "Permissions denied")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCameraBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (allPermissionsGranted()) {
            startCamera()
        } else {
            requestMultiplePermissions.launch(REQUIRED_PERMISSIONS)
        }

        binding.captureButton.setOnClickListener {
            capturePhoto()
        }

        binding.closeButton.setOnClickListener {
            binding.capturedImageContainer.visibility = View.GONE
            binding.captureButton.visibility = View.VISIBLE
            startCamera()
        }

        binding.openGalleryButton.setOnClickListener {
            openGallery()
        }

        binding.sourceLangSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    retranslateText()
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                }

            }
        binding.targetLangSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    retranslateText()
                }

                override fun onNothingSelected(parent: AdapterView<*>) {}
            }

        binding.iconSwap.setOnClickListener {
            swapLanguages()
            retranslateText()
        }

    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(requireContext(), it) == PackageManager.PERMISSION_GRANTED
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(requireContext())
        cameraProviderFuture.addListener({
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder()
                .build().also {
                    it.setSurfaceProvider(binding.previewView.surfaceProvider)
                }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture)
            } catch (e: Exception) {
                Log.e("CameraFragment", "Failed to bind camera", e)
            }
        }, ContextCompat.getMainExecutor(requireContext()))
    }

    private fun capturePhoto() {
        val imageCapture = imageCapture ?: return

        // take picture truyền 3 tham số (call back lưu fail or success , executor , call back sử lý kết quả ảnh sau khi chụp)
        imageCapture.takePicture(
            ContextCompat.getMainExecutor(requireContext()),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val bitmap = imageProxyToBitmap(image)
                    capturedBitmap = bitmap
                    recognizeTextFromBitmap(bitmap)
                    displayCapturedImage(bitmap)
                    image.close()
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.e("CameraFragment", "Error capturing image", exception)
                }
            })
    }

    private fun displayCapturedImage(bitmap: Bitmap) {
        binding.capturedImageView.setImageBitmap(bitmap)
        binding.capturedImageContainer.visibility = View.VISIBLE
        binding.captureButton.visibility = View.GONE
    }


    private fun imageProxyToBitmap(imageProxy: ImageProxy): Bitmap {
        val planeProxy = imageProxy.planes[0]
        val buffer: ByteBuffer = planeProxy.buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    private fun recognizeTextFromBitmap(bitmap: Bitmap) {
        val image = InputImage.fromBitmap(bitmap, 0)

        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

        recognizer.process(image)
            .addOnSuccessListener { visionText ->
                processTextRecognitionResult(visionText)

            }
            .addOnFailureListener { e ->
                Log.e("CameraFragment", "Text recognition failed", e)
            }
    }

    private fun processTextRecognitionResult(text: Text) {
        recognizedTextBlocks.clear()
        originalTextBlocks.clear()

        for (block in text.textBlocks) {
            val blockText = block.text // Lấy toàn bộ đoạn văn bản của block
            originalTextBlocks.add(blockText) // Lưu đoạn văn bản

            // Lấy các điểm góc của block để vẽ khung bao quanh
            val cornerPoints = block.cornerPoints
            if (cornerPoints != null && cornerPoints.size == 4) {
                recognizedTextBlocks.add(
                    Quad(
                        cornerPoints[0],
                        cornerPoints[1],
                        cornerPoints[2],
                        cornerPoints[3]
                    )
                )
            }
        }

        retranslateText()
    }

    private fun translateText(
        sourceLang: String,
        targetLang: String,
        originalTexts: List<String>,
        recognizedTextElements: List<Quad>
    ) {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(sourceLang)
            .setTargetLanguage(targetLang)
            .build()

        currentTranslator?.close()

        val translator = Translation.getClient(options)

        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                val translatedTexts = mutableListOf<String>()
                var completedTranslations = 0

                for ((index, text) in originalTexts.withIndex()) {
                    translator.translate(text)
                        .addOnSuccessListener { translatedText ->
                            translatedTexts.add(translatedText)
                            completedTranslations++

                            // Khi dịch xong tất cả các đoạn, ta sẽ hiển thị
                            if (completedTranslations == originalTexts.size) {
                                drawTranslatedTextWithRotation(
                                    recognizedTextElements,
                                    translatedTexts
                                )
                            }
                        }
                        .addOnFailureListener { e ->
                            Log.e("CameraFragment", "Translation failed", e)
                        }
                }
            }
            .addOnFailureListener { e ->
                Log.e("CameraFragment", "Model download failed", e)
            }
    }

    private fun drawTranslatedTextWithRotation(
        recognizedTextElements: List<Quad>,
        translatedTexts: List<String>
    ) {
        val bitmapWithTranslations = capturedBitmap?.copy(Bitmap.Config.ARGB_8888, true) ?: return

        val canvas = Canvas(bitmapWithTranslations)

        val paintBackground = Paint().apply {
            color = Color.argb(180, 0, 0, 0) // Semi-transparent black background
            style = Paint.Style.FILL
        }

        val paintText = Paint().apply {
            color = Color.WHITE // Text color
            textSize = 45f // Font size
            textAlign = Paint.Align.LEFT
            style = Paint.Style.FILL
            setShadowLayer(1.5f, 1.0f, 1.0f, Color.BLACK) // Adding shadow effect to the text
        }

        val padding = 20f // Thêm padding để đảm bảo khung không bị dính vào văn bản

        for ((index, quad) in recognizedTextElements.withIndex()) {
            val translatedText = translatedTexts.getOrNull(index) ?: ""

            // Calculate rotation angle from corner points
            val deltaX = quad.topRight.x - quad.topLeft.x
            val deltaY = quad.topRight.y - quad.topLeft.y
            val angle = Math.toDegrees(atan2(deltaY.toDouble(), deltaX.toDouble())).toFloat()

            // Calculate width and height of the bounding box using corner points
            val width = Math.sqrt((deltaX * deltaX + deltaY * deltaY).toDouble()).toFloat()
            val height = Math.sqrt(
                ((quad.bottomLeft.x - quad.topLeft.x).toDouble().pow(2.0) +
                        (quad.bottomLeft.y - quad.topLeft.y).toDouble().pow(2.0))
            ).toFloat()

            val centerX = (quad.topLeft.x + quad.bottomRight.x) / 2
            val centerY = (quad.topLeft.y + quad.bottomRight.y) / 2

            canvas.save()

            // Move canvas to the center of the text block
            canvas.translate(centerX.toFloat(), centerY.toFloat())

            // Rotate canvas based on the angle of the text block
            canvas.rotate(angle)

            // Draw the background rectangle around the text with padding
            val left = -width / 2 - padding
            val top = -height / 2 - padding
            val right = width / 2 + padding
            val bottom = height / 2 + padding

            // Draw background for the text with padding
            canvas.drawRect(left, top, right, bottom, paintBackground)

            // Split the translated text into lines and draw each line
            val textLines = breakTextIntoLines(translatedText, right - left, paintText)
            var currentY = top + 45f // Adjust starting Y position for text

            for (line in textLines) {
                canvas.drawText(
                    line,
                    left + 10,
                    currentY,
                    paintText
                ) // Adjust X position for text alignment
                currentY += paintText.textSize + 10 // Line spacing
            }

            // Restore the canvas after the rotation and translation
            canvas.restore()
        }

        displayCapturedImage(bitmapWithTranslations)
    }

    private fun breakTextIntoLines(text: String, boxWidth: Float, paintText: Paint): List<String> {
        val lines = mutableListOf<String>()
        var currentLine = ""
        val words = text.split(" ")  // Tách văn bản thành các từ

        for (word in words) {
            // Kiểm tra nếu thêm từ này vào dòng hiện tại thì chiều rộng của dòng có vượt quá giới hạn không
            val potentialLine = if (currentLine.isEmpty()) word else "$currentLine $word"
            val lineWidth = paintText.measureText(potentialLine)

            if (lineWidth <= boxWidth) {
                // Nếu chiều rộng của dòng vẫn trong giới hạn thì thêm từ vào dòng
                currentLine = potentialLine
            } else {
                // Nếu chiều rộng vượt quá giới hạn thì kết thúc dòng hiện tại và bắt đầu dòng mới
                lines.add(currentLine)
                currentLine = word
            }
        }

        // Thêm dòng cuối cùng vào danh sách
        if (currentLine.isNotEmpty()) {
            lines.add(currentLine)
        }

        return lines
    }


    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            // Sử dụng ContentResolver để mở stream và giải mã thành Bitmap
            val inputStream = requireContext().contentResolver.openInputStream(it)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close() // Đảm bảo đóng stream
            capturedBitmap = bitmap
            displayCapturedImage(bitmap)
            recognizeTextFromBitmap(bitmap)
        }
    }


    private fun openGallery() {
        pickImageLauncher.launch("image/*") // Chọn loại file là ảnh
    }

    private fun getLanguageCode(language: String): String? {
        return when (language) {
            "English" -> TranslateLanguage.ENGLISH
            "Vietnamese" -> TranslateLanguage.VIETNAMESE
            "French" -> TranslateLanguage.FRENCH
            "Spanish" -> TranslateLanguage.SPANISH
            "Japanese" -> TranslateLanguage.JAPANESE
            else -> null
        }
    }

    private fun retranslateText() {
        val sourceLang = getLanguageCode(binding.sourceLangSpinner.selectedItem.toString())
        val targetLang = getLanguageCode(binding.targetLangSpinner.selectedItem.toString())

        if (sourceLang != null && targetLang != null && originalTextBlocks.isNotEmpty()) {
            translateText(sourceLang, targetLang, originalTextBlocks, recognizedTextBlocks)
        }
    }


    private fun swapLanguages() {

        val sourceLangPosition = binding.sourceLangSpinner.selectedItemPosition
        val targetLangPosition = binding.targetLangSpinner.selectedItemPosition

        binding.sourceLangSpinner.setSelection(targetLangPosition)
        binding.targetLangSpinner.setSelection(sourceLangPosition)
    }


    }
