package com.duyth10.mlkit

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.duyth10.mlkit.databinding.FragmentMainBinding
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MainFragment : Fragment() {

    private var _binding: FragmentMainBinding? = null
    private val binding get() = _binding!!
    private var currentTranslator: Translator? = null


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMainBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // choose picture
//        binding.selectImageButton.setOnClickListener {
//            openImagePicker()
//        }

        binding.iconSwap.setOnClickListener {
            swapLanguages()
        }

        // Navigate to CameraFragment
        binding.btnCamera.setOnClickListener {
            (activity as MainActivity).supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, CameraFragment())
                .addToBackStack(null)
                .commit()
        }

        binding.inputText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Gọi hàm dịch văn bản khi có thay đổi
                val sourceLang = getLanguageCode(binding.sourceLangSpinner.selectedItem.toString())
                val targetLang = getLanguageCode(binding.targetLangSpinner.selectedItem.toString())

                if (sourceLang != null && targetLang != null) {
                    translateText(sourceLang, targetLang, binding.inputText.text.toString())
                } else {
                    Toast.makeText(requireContext(), "Ngôn ngữ không hợp lệ", Toast.LENGTH_SHORT).show()
                }
            }

            override fun afterTextChanged(s: Editable?) {}
        })

    }
    private fun getLanguageCode(language: String): String? {
        return when (language) {
            "English" -> TranslateLanguage.ENGLISH
            "Vietnamese" -> TranslateLanguage.VIETNAMESE
            "French" -> TranslateLanguage.FRENCH
            "Spanish" -> TranslateLanguage.SPANISH
            "Japanese" -> TranslateLanguage.JAPANESE
            else -> null
        }
    }

    private fun translateText(sourceLang: String, targetLang: String,text: String) {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(sourceLang)
            .setTargetLanguage(targetLang)
            .build()

        // Hủy translator cũ để tiết kiệm tài nguyên
        currentTranslator?.close()

        val translator: Translator = Translation.getClient(options)

        // Tải ngôn ngữ nếu cần
        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                val text = binding.inputText.text.toString()

                // Dịch văn bản
                translator.translate(text)
                    .addOnSuccessListener { translatedText ->
                        binding.outputText.text = translatedText
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(requireContext(), "Lỗi dịch: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(), "Lỗi tải ngôn ngữ: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }


//    private fun openImagePicker() {
//        val intent = Intent(Intent.ACTION_PICK)
//        intent.type = "image/*"
//        pickImageLauncher.launch(intent)
//    }

    //
//    private fun recognizeTextFromImage(imageUri: Uri) {
//        val image: InputImage
//        try {
//            val bitmap: Bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
//                val source = ImageDecoder.createSource(requireActivity().contentResolver, imageUri)
//                ImageDecoder.decodeBitmap(source)
//            } else {
//                MediaStore.Images.Media.getBitmap(requireActivity().contentResolver, imageUri)
//            }
//            image = InputImage.fromBitmap(bitmap, 0)
//
//            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
//            recognizer.process(image)
//                .addOnSuccessListener { visionText ->
//                    binding.inputText.setText(visionText.text)
//                    translateText(visionText.text)
//                }
//                .addOnFailureListener { e ->
//                    Toast.makeText(requireContext(), "Error recognizing text: ${e.message}", Toast.LENGTH_SHORT).show()
//                }
//
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//    }
//    private val pickImageLauncher = registerForActivityResult(
//        ActivityResultContracts.StartActivityForResult()
//    ) { result ->
//        if (result.resultCode == AppCompatActivity.RESULT_OK) {
//            val imageUri: Uri? = result.data?.data
//            if (imageUri != null) {
//                binding.imageView.setImageURI(imageUri)
//                recognizeTextFromImage(imageUri)
//            }
//        }
//    }



    private fun swapLanguages() {

        val sourceLangPosition = binding.sourceLangSpinner.selectedItemPosition
        val targetLangPosition = binding.targetLangSpinner.selectedItemPosition

        // Hoán đổi vị trí
        binding.sourceLangSpinner.setSelection(targetLangPosition)
        binding.targetLangSpinner.setSelection(sourceLangPosition)

        // (Tùy chọn) Hoán đổi nội dung giữa inputText và outputText
        val currentInputText = binding.inputText.text.toString()
        val currentOutputText = binding.outputText.text.toString()

        binding.inputText.setText(currentOutputText)
        binding.outputText.text = currentInputText


    }

    override fun onDestroyView() {
        super.onDestroyView()
        currentTranslator?.close() // Avoid memory leaks
        _binding = null
    }
}
