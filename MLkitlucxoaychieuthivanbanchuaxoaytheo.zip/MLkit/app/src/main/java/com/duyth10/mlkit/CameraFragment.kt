package com.duyth10.mlkit

import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.media.Image
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.isInvisible
import androidx.fragment.app.Fragment
import com.duyth10.mlkit.databinding.FragmentCameraBinding
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.nio.ByteBuffer
import java.util.concurrent.ExecutionException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors


class CameraFragment : Fragment() {

    private var _binding: FragmentCameraBinding? = null
    private val binding get() = _binding!!
    private lateinit var imageCapture: ImageCapture
    private var capturedBitmap: Bitmap? = null

    private val REQUIRED_PERMISSIONS = arrayOf(
        android.Manifest.permission.CAMERA
    )

    private val requestMultiplePermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.all { it.value }) {
            startCamera()
        } else {
            Log.d("permissions", "Permissions denied")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCameraBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (allPermissionsGranted()) {
            startCamera()
        } else {
            requestMultiplePermissions.launch(REQUIRED_PERMISSIONS)
        }

        binding.captureButton.setOnClickListener {
            capturePhoto()
        }

        binding.closeButton.setOnClickListener {
            binding.capturedImageContainer.visibility = View.GONE
            binding.captureButton.visibility = View.VISIBLE
            startCamera()
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(requireContext(), it) == PackageManager.PERMISSION_GRANTED
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(requireContext())
        cameraProviderFuture.addListener({
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder()
                .build().also {
                    it.setSurfaceProvider(binding.previewView.surfaceProvider)
                }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture)
            } catch (e: Exception) {
                Log.e("CameraFragment", "Failed to bind camera", e)
            }
        }, ContextCompat.getMainExecutor(requireContext()))
    }

    private fun capturePhoto() {
        val imageCapture = imageCapture ?: return

        imageCapture.takePicture(
            ContextCompat.getMainExecutor(requireContext()),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val bitmap = imageProxyToBitmap(image)
                    capturedBitmap = bitmap // Lưu bitmap vào thuộc tính
                    recognizeTextFromBitmap(bitmap)
                    displayCapturedImage(bitmap)
                    image.close()
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.e("CameraFragment", "Error capturing image", exception)
                }
            })
    }

    private fun displayCapturedImage(bitmap: Bitmap) {
        binding.capturedImageView.setImageBitmap(bitmap)
        binding.capturedImageContainer.visibility = View.VISIBLE
        binding.captureButton.visibility = View.GONE
    }

    private fun imageProxyToBitmap(imageProxy: ImageProxy): Bitmap {
        val planeProxy = imageProxy.planes[0]
        val buffer: ByteBuffer = planeProxy.buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    private fun recognizeTextFromBitmap(bitmap: Bitmap) {
        val image = InputImage.fromBitmap(bitmap, 0)

        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

        recognizer.process(image)
            .addOnSuccessListener { visionText ->
                processTextRecognitionResult(visionText)
            }
            .addOnFailureListener { e ->
                Log.e("CameraFragment", "Text recognition failed", e)
            }
    }

//    private fun processTextRecognitionResult(text: Text) {
//        val resultText = StringBuilder()
//        val recognizedTextElements = mutableListOf<Quad>() // Sử dụng một lớp để lưu 4 điểm góc của mỗi chữ
//
//        for (block in text.textBlocks) {
//            for (line in block.lines) {
//                resultText.append(line.text).append("\n")
//                for (element in line.elements) {
//                    val cornerPoints = element.cornerPoints // Lấy các điểm góc của từng ký tự
//                    if (cornerPoints != null && cornerPoints.size == 4) {
//                        // Lưu 4 điểm góc của ký tự vào danh sách
//                        recognizedTextElements.add(Quad(cornerPoints[0], cornerPoints[1], cornerPoints[2], cornerPoints[3]))
//                    }
//                }
//            }
//        }
//
//        Log.d("CameraFragment", "Recognized Text: $resultText")
//
//        // Vẽ các bounding box nghiêng
//        drawRotatedBoundingBoxes(recognizedTextElements)
//    }


    private fun processTextRecognitionResult(text: Text) {
        val recognizedTextBlocks = mutableListOf<Quad>() // Sử dụng cho toàn bộ block (hoặc line)
        val originalTextBlocks = mutableListOf<String>() // Lưu trữ các đoạn văn bản cần dịch

        for (block in text.textBlocks) {
            val blockText = block.text // Lấy toàn bộ đoạn văn bản của block
            originalTextBlocks.add(blockText) // Lưu đoạn văn bản

            // Lấy các điểm góc của block để vẽ khung bao quanh
            val cornerPoints = block.cornerPoints
            if (cornerPoints != null && cornerPoints.size == 4) {
                recognizedTextBlocks.add(Quad(cornerPoints[0], cornerPoints[1], cornerPoints[2], cornerPoints[3]))
            }
        }

        // Sau khi có các đoạn văn bản và vị trí của chúng, bắt đầu quá trình dịch
        translateText(originalTextBlocks, recognizedTextBlocks)
    }

    private fun translateText(originalTexts: List<String>, recognizedTextElements: List<Quad>) {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)  // Ngôn ngữ nguồn (có thể thay đổi tùy theo đầu vào)
            .setTargetLanguage(TranslateLanguage.VIETNAMESE)  // Ngôn ngữ đích là tiếng Việt
            .build()

        val translator = Translation.getClient(options)

        // Tải mô hình dịch trước khi bắt đầu dịch
        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                val translatedTexts = mutableListOf<String>()
                var completedTranslations = 0

                for ((index, text) in originalTexts.withIndex()) {
                    translator.translate(text)
                        .addOnSuccessListener { translatedText ->
                            translatedTexts.add(translatedText)
                            completedTranslations++

                            // Khi dịch xong tất cả các đoạn, ta sẽ hiển thị
                            if (completedTranslations == originalTexts.size) {
                                drawTranslatedTextWithImprovedDisplay(recognizedTextElements, translatedTexts)
                            }
                        }
                        .addOnFailureListener { e ->
                            Log.e("CameraFragment", "Translation failed", e)
                        }
                }
            }
            .addOnFailureListener { e ->
                Log.e("CameraFragment", "Model download failed", e)
            }
    }


    private fun drawTranslatedTextWithImprovedDisplay(recognizedTextElements: List<Quad>, translatedTexts: List<String>) {
        val bitmapWithTranslations = capturedBitmap?.copy(Bitmap.Config.ARGB_8888, true)
            ?: return

        val canvas = Canvas(bitmapWithTranslations)

        // Định nghĩa paint cho nền văn bản
        val paintBackground = Paint().apply {
            color = Color.argb(180, 0, 0, 0) // Màu nền đen với độ mờ
            style = Paint.Style.FILL
        }

        // Định nghĩa paint cho văn bản
        val paintText = Paint().apply {
            color = Color.WHITE // Màu chữ trắng
            textSize = 45f // Kích thước chữ lớn hơn
            textAlign = Paint.Align.LEFT
            style = Paint.Style.FILL
            setShadowLayer(1.5f, 1.0f, 1.0f, Color.BLACK) // Hiệu ứng bóng cho văn bản
        }

        for ((index, quad) in recognizedTextElements.withIndex()) {
            val translatedText = translatedTexts.getOrNull(index) ?: ""

            val left = quad.topLeft.x.toFloat()
            val top = quad.topLeft.y.toFloat()
            val right = quad.bottomRight.x.toFloat()
            val bottom = quad.bottomRight.y.toFloat()

            // Vẽ nền mờ
            canvas.drawRect(left, top, right, bottom, paintBackground)

            // Chia văn bản thành nhiều dòng nếu cần
            val boxWidth = right - left
            val textLines = breakTextIntoLines(translatedText, boxWidth, paintText)

            var currentY = top + 45f // Bắt đầu từ vị trí top cộng với khoảng cách
            for (line in textLines) {
                canvas.drawText(line, left + 10, currentY, paintText) // Căn trái và có khoảng cách
                currentY += paintText.textSize + 10 // Cập nhật vị trí Y cho dòng tiếp theo
            }
        }

        displayCapturedImage(bitmapWithTranslations)
    }


    /**
     * Hàm này tách văn bản thành các dòng phù hợp với chiều rộng của hộp văn bản
     */
    private fun breakTextIntoLines(text: String, boxWidth: Float, paintText: Paint): List<String> {
        val lines = mutableListOf<String>()
        var currentLine = ""
        val words = text.split(" ")  // Tách văn bản thành các từ

        for (word in words) {
            // Kiểm tra nếu thêm từ này vào dòng hiện tại thì chiều rộng của dòng có vượt quá giới hạn không
            val potentialLine = if (currentLine.isEmpty()) word else "$currentLine $word"
            val lineWidth = paintText.measureText(potentialLine)

            if (lineWidth <= boxWidth) {
                // Nếu chiều rộng của dòng vẫn trong giới hạn thì thêm từ vào dòng
                currentLine = potentialLine
            } else {
                // Nếu chiều rộng vượt quá giới hạn thì kết thúc dòng hiện tại và bắt đầu dòng mới
                lines.add(currentLine)
                currentLine = word
            }
        }

        // Thêm dòng cuối cùng vào danh sách
        if (currentLine.isNotEmpty()) {
            lines.add(currentLine)
        }

        return lines
    }

//    private fun rotatePoints(points: Array<Point>, rotationDegrees: Int, width: Int, height: Int): Array<Point> {
//        val newPoints = Array(points.size) { Point() }
//        val matrix = Matrix()
//
//        // Tạo ma trận xoay dựa trên góc độ và tâm ảnh
//        matrix.postRotate(rotationDegrees.toFloat(), width / 2f, height / 2f)
//
//        // Áp dụng phép xoay với từng điểm
//        for (i in points.indices) {
//            val point = floatArrayOf(points[i].x.toFloat(), points[i].y.toFloat())
//            matrix.mapPoints(point)
//            newPoints[i] = Point(point[0].toInt(), point[1].toInt())
//        }
//        return newPoints
//    }
//



    //    private fun drawRotatedBoundingBoxes(recognizedTextElements: List<Quad>) {
    //        val bitmapWithBoxes = capturedBitmap?.copy(Bitmap.Config.ARGB_8888, true)
    //            ?: return // Trả về nếu bitmap là null
    //
    //        val canvas = Canvas(bitmapWithBoxes)
    //        val paint = Paint().apply {
    //            color = Color.RED
    //            style = Paint.Style.STROKE
    //            strokeWidth = 5f
    //        }
    //
    //        for (quad in recognizedTextElements) {
    //            // Vẽ các đường nối giữa các điểm góc để tạo hình chữ nhật nghiêng
    //            canvas.drawLine(quad.topLeft.x.toFloat(), quad.topLeft.y.toFloat(),
    //                quad.topRight.x.toFloat(), quad.topRight.y.toFloat(), paint)
    //
    //            canvas.drawLine(quad.topRight.x.toFloat(), quad.topRight.y.toFloat(),
    //                quad.bottomRight.x.toFloat(), quad.bottomRight.y.toFloat(), paint)
    //
    //            canvas.drawLine(quad.bottomRight.x.toFloat(), quad.bottomRight.y.toFloat(),
    //                quad.bottomLeft.x.toFloat(), quad.bottomLeft.y.toFloat(), paint)
    //
    //            canvas.drawLine(quad.bottomLeft.x.toFloat(), quad.bottomLeft.y.toFloat(),
    //                quad.topLeft.x.toFloat(), quad.topLeft.y.toFloat(), paint)
    //        }
    //
    //        // Hiển thị ảnh đã chỉnh sửa với các bounding box nghiêng
    //        displayCapturedImage(bitmapWithBoxes)
    //    }


}
